# Periodismo de datos en UC3M
## USUARIO
**Victoria Fuertes González**
## ¿Qué es el Periodismo de Datos?
### Tres saberes implicados: 
- Periodismo
- Visualización
- Datos
## Prácticas realizadas hasta la fecha
1. Comentario infografía 
2. Comentario infografía desde terminal
3. Gráfico con Datawrapper (actividad 4)

